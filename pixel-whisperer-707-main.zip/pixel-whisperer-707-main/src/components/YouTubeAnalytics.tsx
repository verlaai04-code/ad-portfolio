import { motion } from "framer-motion";
import { Eye, TrendingUp, Youtube } from "lucide-react";

type Row = { label: string; views: number };

// Jewelry brand campaign — bar list (kept as-is)
const TOP_CONTENT: Row[] = [
  { label: "Bangles from Premium Khaja, Charminar (Miss World)", views: 1800 },
  { label: "Top 5 Traditional Hyderabad Nizami Jewellery", views: 1800 },
  { label: "6 bangle set — all colours available", views: 1700 },
  { label: "Royal charm of Hyderabadi Handmade Jewellery", views: 1100 },
  { label: "When tradition meets design — Lac bangles", views: 976 },
  { label: "Traditional vibes with a modern beat", views: 737 },
  { label: "Premium Khaja bangles (second cut)", views: 441 },
  { label: "Viral Hyderabadi Minkari Lac bangles", views: 397 },
  { label: "Beautiful lac bangles — ₹200/pair", views: 383 },
  { label: "Natural pearl earrings with AD stone", views: 382 },
];

// Personal brand (Growth Grid channel) — rendered as a graph
const PERSONAL: Row[] = [
  { label: "#dhurandhar2 · #LetsWedVenture · Wedding Planning", views: 21700 },
  { label: "#dhurandhar2 · #marketingtips · memes", views: 5300 },
  { label: "YIIC 6.0 experience — learning to building", views: 271 },
  { label: "#dhurandhar · marketingagency · social media", views: 9 },
  { label: "#weddingideas · dreamwedding · invites", views: 7 },
  { label: "LetsWedVenture — invites reimagined", views: 4 },
  { label: "Day 1 of my journey · #StartupJourney", views: 3 },
  { label: "Day 1 of building Velra.ai", views: 1 },
];

const TOTAL_PERSONAL = PERSONAL.reduce((s, r) => s + r.views, 0);
const TOTAL_JEWELRY = TOP_CONTENT.reduce((s, r) => s + r.views, 0);
const GRAND = TOTAL_PERSONAL + TOTAL_JEWELRY;

function Bar({ row, max, color }: { row: Row; max: number; color: string }) {
  const pct = Math.max(2, (row.views / max) * 100);
  return (
    <div className="group">
      <div className="flex items-baseline justify-between gap-3">
        <p className="truncate text-xs text-foreground/85 md:text-sm">{row.label}</p>
        <p className="shrink-0 font-display text-sm tabular-nums text-foreground">
          {row.views >= 1000 ? `${(row.views / 1000).toFixed(1)}k` : row.views}
        </p>
      </div>
      <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-surface-2">
        <motion.div
          initial={{ width: 0 }}
          whileInView={{ width: `${pct}%` }}
          viewport={{ once: true }}
          transition={{ duration: 1.1, ease: [0.22, 1, 0.36, 1] }}
          className={`h-full rounded-full ${color}`}
        />
      </div>
    </div>
  );
}

function PersonalGraph({ rows }: { rows: Row[] }) {
  // Reverse chronological → chart left-to-right oldest → newest
  const series = [...rows].reverse();
  const W = 560;
  const H = 220;
  const PAD = 24;
  const max = Math.max(...series.map((s) => s.views));
  const stepX = (W - PAD * 2) / (series.length - 1);
  const points = series.map((r, i) => {
    const x = PAD + i * stepX;
    const y = PAD + (H - PAD * 2) * (1 - r.views / max);
    return { x, y, r };
  });
  const path = points.map((p, i) => `${i === 0 ? "M" : "L"}${p.x},${p.y}`).join(" ");
  const area = `${path} L${points[points.length - 1].x},${H - PAD} L${points[0].x},${H - PAD} Z`;

  return (
    <div className="relative">
      <svg viewBox={`0 0 ${W} ${H}`} className="h-auto w-full">
        <defs>
          <linearGradient id="growthFill" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor="oklch(0.82 0.13 350)" stopOpacity="0.45" />
            <stop offset="100%" stopColor="oklch(0.82 0.13 350)" stopOpacity="0" />
          </linearGradient>
          <linearGradient id="growthLine" x1="0" x2="1" y1="0" y2="0">
            <stop offset="0%" stopColor="oklch(0.99 0.005 340)" />
            <stop offset="100%" stopColor="oklch(0.78 0.15 350)" />
          </linearGradient>
        </defs>
        {/* grid */}
        {[0.25, 0.5, 0.75].map((p) => (
          <line
            key={p}
            x1={PAD}
            x2={W - PAD}
            y1={PAD + (H - PAD * 2) * p}
            y2={PAD + (H - PAD * 2) * p}
            stroke="oklch(1 0 0 / 0.06)"
            strokeDasharray="2 4"
          />
        ))}
        <motion.path
          d={area}
          fill="url(#growthFill)"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1, delay: 0.4 }}
        />
        <motion.path
          d={path}
          fill="none"
          stroke="url(#growthLine)"
          strokeWidth={2.5}
          strokeLinecap="round"
          strokeLinejoin="round"
          initial={{ pathLength: 0 }}
          whileInView={{ pathLength: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1] }}
        />
        {points.map((p, i) => (
          <motion.circle
            key={i}
            cx={p.x}
            cy={p.y}
            r={3.5}
            fill="oklch(0.99 0.005 340)"
            stroke="oklch(0.78 0.15 350)"
            strokeWidth={1.5}
            initial={{ opacity: 0, scale: 0 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4, delay: 0.5 + i * 0.05 }}
          />
        ))}
      </svg>
      {/* Peak callout */}
      <div className="mt-4 flex items-center justify-between border-t border-stroke pt-4 text-xs text-muted-foreground">
        <span>Channel growth · {series.length} uploads</span>
        <span className="font-display text-base text-foreground">
          Peak {(max / 1000).toFixed(1)}k views
        </span>
      </div>
    </div>
  );
}

export function YouTubeAnalytics() {
  return (
    <section className="relative mx-auto max-w-7xl px-6 py-24 md:py-32">
      <div className="pointer-events-none absolute -left-10 top-20 h-72 w-72 rounded-full bg-azure/15 blur-3xl" />
      <div className="pointer-events-none absolute -right-10 bottom-20 h-72 w-72 rounded-full bg-gold/15 blur-3xl" />

      <div className="relative flex flex-wrap items-end justify-between gap-6">
        <div>
          <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">
            Channel · Growth Grid
          </p>
          <h2 className="mt-3 font-display text-4xl md:text-6xl">
            Personal <span className="italic text-gradient">graphics</span> &amp; brand work
          </h2>
          <p className="mt-3 max-w-xl text-muted-foreground">
            My YouTube channel <span className="text-foreground">Growth Grid</span> — personal
            brand storytelling on the left as a growth graph, and a 15-day jewelry brand
            campaign on the right.
          </p>
        </div>
        <div className="flex items-center gap-4 rounded-2xl border border-stroke bg-surface px-5 py-4">
          <Youtube className="h-6 w-6 text-red-500" />
          <div>
            <p className="font-display text-3xl text-foreground">
              {(GRAND / 1000).toFixed(1)}k+
            </p>
            <p className="text-[11px] uppercase tracking-[0.25em] text-muted-foreground">
              Total lifetime views
            </p>
          </div>
        </div>
      </div>

      <div className="relative mt-10 grid gap-5 md:grid-cols-2">
        <div className="rounded-3xl border border-stroke bg-surface p-6 md:p-8">
          <div className="mb-5 flex items-center justify-between">
            <div>
              <p className="text-[11px] uppercase tracking-[0.3em] text-muted-foreground">
                Growth Grid
              </p>
              <h3 className="mt-1 font-display text-2xl md:text-3xl">Personal Brand</h3>
            </div>
            <div className="text-right">
              <p className="font-display text-2xl text-gradient">
                {(TOTAL_PERSONAL / 1000).toFixed(1)}k
              </p>
              <p className="text-[11px] uppercase tracking-[0.25em] text-muted-foreground">
                Views
              </p>
            </div>
          </div>
          <PersonalGraph rows={PERSONAL} />
        </div>

        <div className="rounded-3xl border border-stroke bg-surface p-6 md:p-8">
          <div className="mb-5 flex items-center justify-between">
            <div>
              <p className="text-[11px] uppercase tracking-[0.3em] text-muted-foreground">
                Lifetime
              </p>
              <h3 className="mt-1 font-display text-2xl md:text-3xl">Jewelry Brand Campaign</h3>
            </div>
            <div className="text-right">
              <p className="font-display text-2xl text-gradient">
                {(TOTAL_JEWELRY / 1000).toFixed(1)}k
              </p>
              <p className="text-[11px] uppercase tracking-[0.25em] text-muted-foreground">
                Views
              </p>
            </div>
          </div>
          <div className="space-y-3.5">
            {TOP_CONTENT.map((r) => (
              <Bar
                key={r.label}
                row={r}
                max={Math.max(...TOP_CONTENT.map((x) => x.views))}
                color="bg-gradient-to-r from-gold to-azure"
              />
            ))}
          </div>
        </div>
      </div>

      <div className="relative mt-6 grid gap-3 sm:grid-cols-3">
        {[
          { icon: Eye, k: `${(GRAND / 1000).toFixed(1)}k`, v: "Lifetime views" },
          { icon: TrendingUp, k: "21.7k", v: "Top video reach" },
          { icon: Youtube, k: "18+", v: "Tracked uploads" },
        ].map((s) => (
          <div
            key={s.v}
            className="flex items-center gap-4 rounded-2xl border border-stroke bg-surface/60 p-5"
          >
            <s.icon className="h-5 w-5 text-azure" />
            <div>
              <p className="font-display text-2xl">{s.k}</p>
              <p className="text-xs uppercase tracking-[0.25em] text-muted-foreground">
                {s.v}
              </p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
