import { motion } from "framer-motion";
import { Award, ExternalLink, FileText } from "lucide-react";
import scaler from "@/assets/creds/scaler.jpeg.asset.json";
import midnight from "@/assets/creds/midnight.jpeg.asset.json";
import iitm from "@/assets/creds/iitm.jpeg.asset.json";
import codingjr from "@/assets/creds/codingjr.jpeg.asset.json";
import codingjrCert from "@/assets/creds/codingjr-cert.pdf.asset.json";
import codingjrLor from "@/assets/creds/codingjr-lor.pdf.asset.json";

type Item = {
  title: string;
  org: string;
  blurb: string;
  image: string;
  accent: "azure" | "gold" | "lime" | "violet";
  links?: { label: string; href: string }[];
};

const ITEMS: Item[] = [
  {
    title: "B.S. in Data Science & Applications",
    org: "IIT Madras",
    blurb:
      "Qualified the IIT Madras BS Degree foundational exam — admitted to the Data Science program after Class XII.",
    image: iitm.url,
    accent: "gold",
  },
  {
    title: "Young Innovator Internship Challenge",
    org: "Scaler School of Technology",
    blurb:
      "Certificate of Excellence — recognised for outstanding performance and commitment during the 5-week YIIC program.",
    image: scaler.url,
    accent: "violet",
  },
  {
    title: "Founder, Midnight Builders",
    org: "Founder community",
    blurb:
      "Built a focused LinkedIn community of serious founders who ship — connecting builders, marketers, and operators.",
    image: midnight.url,
    accent: "lime",
  },
  {
    title: "Library Sciences Intern",
    org: "CodingJr (code4bots Technologies Pvt Ltd)",
    blurb:
      "Selected by the founder for an internship at CodingJr. Received an internship certificate and a letter of recommendation.",
    image: codingjr.url,
    accent: "azure",
    links: [
      { label: "Internship Certificate", href: codingjrCert.url },
      { label: "Letter of Recommendation", href: codingjrLor.url },
    ],
  },
];

const ACCENT: Record<Item["accent"], string> = {
  azure: "from-azure/40",
  gold: "from-gold/40",
  lime: "from-lime-400/40",
  violet: "from-violet-500/40",
};

export function Achievements() {
  return (
    <section className="mx-auto max-w-6xl px-6 pb-20">
      <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">
        Credentials
      </p>
      <h2 className="mt-3 font-display text-3xl md:text-5xl">
        Achievements & <span className="italic text-gradient">recognition</span>
      </h2>

      <div className="mt-8 grid gap-5 md:grid-cols-2">
        {ITEMS.map((it, i) => (
          <motion.article
            key={it.title}
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.55, delay: i * 0.05 }}
            className="group relative overflow-hidden rounded-3xl border border-stroke bg-surface"
          >
            <div
              className={`pointer-events-none absolute -top-20 -right-16 h-52 w-52 rounded-full bg-gradient-to-br ${ACCENT[it.accent]} to-transparent blur-3xl opacity-60`}
            />
            <div className="relative aspect-[16/10] overflow-hidden border-b border-stroke bg-background">
              <img
                src={it.image}
                alt={`${it.title} — ${it.org}`}
                loading="lazy"
                className="h-full w-full object-cover object-center transition-transform duration-700 group-hover:scale-[1.04]"
              />
              <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-background/70 via-transparent to-transparent" />
            </div>
            <div className="relative p-6">
              <div className="flex items-center gap-2 text-[11px] uppercase tracking-[0.25em] text-gold">
                <Award className="h-3.5 w-3.5" /> {it.org}
              </div>
              <h3 className="mt-2 font-display text-2xl leading-snug">
                {it.title}
              </h3>
              <p className="mt-2 text-sm text-foreground/80">{it.blurb}</p>
              {it.links && (
                <div className="mt-4 flex flex-wrap gap-2">
                  {it.links.map((l) => (
                    <a
                      key={l.href}
                      href={l.href}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1.5 rounded-full border border-stroke bg-surface-2 px-3 py-1.5 text-xs text-foreground/90 transition-colors hover:border-azure hover:text-foreground"
                    >
                      <FileText className="h-3 w-3" /> {l.label}
                      <ExternalLink className="h-3 w-3 opacity-60" />
                    </a>
                  ))}
                </div>
              )}
            </div>
          </motion.article>
        ))}
      </div>
    </section>
  );
}
