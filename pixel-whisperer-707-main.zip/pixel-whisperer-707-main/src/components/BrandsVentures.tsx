import { motion } from "framer-motion";
import bombayMusk from "@/assets/brands/bombay-musk.jpeg.asset.json";
import wedventure from "@/assets/brands/wedventure.jpeg.asset.json";
import zeene from "@/assets/brands/zeene.jpeg.asset.json";
import growthgrid from "@/assets/brands/growthgrid.jpeg.asset.json";
import midnightHero from "@/assets/brands/midnight-builders-hero.jpeg.asset.json";

type Item = {
  src: string;
  title: string;
  tag: string;
  span?: string;
  aspect?: string;
};

const items: Item[] = [
  { src: bombayMusk.url, title: "Bombay Musk", tag: "Freelance · Brand Campaign", span: "md:col-span-7", aspect: "aspect-[4/5] md:aspect-[16/11]" },
  { src: wedventure.url, title: "Let's Wedventure", tag: "Founder · MVP", span: "md:col-span-5", aspect: "aspect-[4/5] md:aspect-[4/3]" },
  { src: midnightHero.url, title: "Midnight Builders", tag: "Founder Community · Founded", span: "md:col-span-8", aspect: "aspect-[4/5] md:aspect-[16/9]" },
  { src: zeene.url, title: "Zeené", tag: "Logo · Hijab Brand", span: "md:col-span-2", aspect: "aspect-square" },
  { src: growthgrid.url, title: "Growth Grid", tag: "Logo · Identity", span: "md:col-span-2", aspect: "aspect-square" },
];



export function BrandsVentures() {
  return (
    <section className="relative py-20 md:py-28">
      <div className="pointer-events-none absolute inset-0 bg-grid opacity-30" />
      <div className="pointer-events-none absolute left-1/2 top-0 h-72 w-72 -translate-x-1/2 rounded-full bg-azure/15 blur-3xl" />
      <div className="relative mx-auto max-w-7xl px-6">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7 }}
          className="mb-12 flex flex-col gap-3"
        >
          <div className="flex items-center gap-3">
            <span className="h-px w-8 bg-stroke" />
            <span className="text-[11px] uppercase tracking-[0.3em] text-muted-foreground">
              Brands & Ventures
            </span>
          </div>
          <h2 className="font-display text-4xl leading-tight md:text-6xl">
            Selected <span className="italic text-gradient">brand work</span>
          </h2>
          <p className="max-w-2xl text-muted-foreground">
            Freelance campaigns, founder ventures, and creative direction for
            Anantnetra Technologies — design systems, identities, and
            content that ships.
          </p>
        </motion.div>

        <div className="grid grid-cols-2 gap-4 md:grid-cols-12 md:gap-5">
          {items.map((it, i) => (
            <motion.figure
              key={it.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.6, delay: i * 0.05 }}
              className={`group relative col-span-1 overflow-hidden rounded-3xl border border-stroke bg-surface ${it.span ?? ""}`}
            >
              <div className={`relative w-full ${it.aspect ?? "aspect-[4/5]"}`}>
                <img
                  src={it.src}
                  alt={it.title}
                  loading="lazy"
                  className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-[1.04]"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background via-background/30 to-transparent opacity-90" />
                <figcaption className="absolute inset-x-0 bottom-0 flex flex-col gap-1 p-4 md:p-5">
                  <span className="text-[10px] uppercase tracking-[0.25em] text-muted-foreground">
                    {it.tag}
                  </span>
                  <span className="font-display text-lg md:text-2xl">
                    {it.title}
                  </span>
                </figcaption>
                <span className="absolute right-3 top-3 rounded-full border border-white/15 bg-black/40 px-2.5 py-1 text-[10px] uppercase tracking-[0.2em] text-white/80 backdrop-blur">
                  {String(i + 1).padStart(2, "0")}
                </span>
              </div>
            </motion.figure>
          ))}
        </div>
      </div>
    </section>
  );
}
