import { Link, useRouterState } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import resumeAsset from "@/assets/resume/AdeenaSiddiqua_Resume.pdf.asset.json";

const links = [
  { to: "/", label: "Home" },
  { to: "/about", label: "About" },
  { to: "/projects", label: "Projects" },
  { to: "/contact", label: "Contact" },
] as const;


export function Navbar() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header className="fixed inset-x-0 top-0 z-50 flex justify-center px-4 pt-4 md:pt-6">
      <nav
        className={`glass flex items-center gap-1 rounded-full px-2 py-2 transition-shadow ${
          scrolled ? "shadow-2xl shadow-black/40" : ""
        }`}
      >
        <Link
          to="/"
          className="group flex items-center gap-2 rounded-full px-2 py-1"
          aria-label="Home"
        >
          <span className="relative grid h-8 w-8 place-items-center rounded-full">
            <span className="absolute inset-0 rounded-full bg-gradient-to-br from-azure to-gold p-[1.5px] animate-gradient">
              <span className="block h-full w-full rounded-full bg-background" />
            </span>
            <span className="relative font-display text-sm italic text-foreground">A</span>
          </span>
          <span className="hidden text-sm font-medium tracking-tight sm:inline">Adeena</span>
        </Link>
        <span className="mx-1 hidden h-5 w-px bg-stroke sm:block" />
        <ul className="flex items-center gap-0.5">
          {links.map((l) => {
            const active = pathname === l.to;
            return (
              <li key={l.to}>
                <Link
                  to={l.to}
                  className={`rounded-full px-3 py-1.5 text-xs sm:px-4 sm:py-2 sm:text-sm transition-colors ${
                    active
                      ? "bg-surface-2 text-foreground"
                      : "text-muted-foreground hover:bg-surface-2/60 hover:text-foreground"
                  }`}
                >
                  {l.label}
                </Link>
              </li>
            );
          })}
        </ul>
        <span className="mx-1 hidden h-5 w-px bg-stroke sm:block" />
        <a
          href={resumeAsset.url}
          target="_blank"
          rel="noopener noreferrer"
          className="hidden rounded-full px-3 py-1.5 text-xs text-muted-foreground transition-colors hover:bg-surface-2/60 hover:text-foreground sm:inline-flex sm:px-4 sm:py-2 sm:text-sm"
        >
          Resume
        </a>
        <Link
          to="/contact"
          className="group relative rounded-full px-3 py-1.5 text-xs sm:px-4 sm:py-2 sm:text-sm"
        >
          <span className="absolute -inset-[1.5px] rounded-full bg-gradient-to-r from-azure to-gold opacity-0 transition-opacity group-hover:opacity-100 animate-gradient" />
          <span className="relative flex items-center gap-1.5 rounded-full bg-surface px-3 py-1 text-foreground">
            Say hi <span aria-hidden>↗</span>
          </span>
        </Link>
      </nav>
    </header>
  );
}
