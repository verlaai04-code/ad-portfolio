import { useChat } from "@ai-sdk/react";
import { useServerFn } from "@tanstack/react-start";
import { DefaultChatTransport, type UIMessage } from "ai";
import { AnimatePresence, motion } from "framer-motion";
import { CheckCircle2, MessageSquare, Send, Sparkles, UserPlus, X } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { submitLead } from "@/lib/leads.functions";

const SESSION_KEY = "adeena_chat_session";
const HISTORY_KEY = "adeena_chat_history";

function getSessionId() {
  if (typeof window === "undefined") return crypto.randomUUID();
  let id = localStorage.getItem(SESSION_KEY);
  if (!id) {
    id = crypto.randomUUID();
    localStorage.setItem(SESSION_KEY, id);
  }
  return id;
}

function loadHistory(): UIMessage[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(HISTORY_KEY);
    return raw ? (JSON.parse(raw) as UIMessage[]) : [];
  } catch {
    return [];
  }
}

const INTRO: UIMessage = {
  id: "intro",
  role: "assistant",
  parts: [
    {
      type: "text",
      text:
        "Hi! I'm Adeena's AI. Ask me about her projects, skills, or how to work with her. If you're hiring or have an opportunity, I can take your details too.",
    },
  ],
};

const SUGGESTIONS = [
  "What does Adeena work on?",
  "Show me her best projects",
  "I'd like to hire her",
];

export function Chatbot() {
  const [open, setOpen] = useState(false);
  const sessionId = useMemo(() => getSessionId(), []);
  const initial = useMemo<UIMessage[]>(() => {
    const h = loadHistory();
    return h.length ? h : [INTRO];
  }, []);

  const transport = useMemo(
    () =>
      new DefaultChatTransport({
        api: "/api/chat",
        body: { sessionId },
      }),
    [sessionId],
  );

  const { messages, sendMessage, status } = useChat({
    id: sessionId,
    messages: initial,
    transport,
  });

  const [input, setInput] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const isLoading = status === "submitted" || status === "streaming";

  const submitLeadFn = useServerFn(submitLead);
  const [leadOpen, setLeadOpen] = useState(false);
  const [leadState, setLeadState] = useState<"idle" | "sending" | "sent" | "error">("idle");
  const [leadErr, setLeadErr] = useState("");

  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      localStorage.setItem(HISTORY_KEY, JSON.stringify(messages));
    } catch {}
  }, [messages]);

  useEffect(() => {
    if (open) inputRef.current?.focus();
  }, [open, messages.length]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, isLoading]);

  const submit = async (text: string) => {
    const t = text.trim();
    if (!t || isLoading) return;
    setInput("");
    await sendMessage({ text: t });
  };

  return (
    <>
      {/* Launcher */}
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-label={open ? "Close chat" : "Open chat with Adeena's AI"}
        className="fixed bottom-5 right-5 z-50 grid h-14 w-14 place-items-center rounded-full bg-gradient-to-br from-azure to-gold text-background shadow-2xl shadow-azure/30 transition-transform hover:scale-105 animate-gradient md:bottom-8 md:right-8"
      >
        <AnimatePresence mode="wait" initial={false}>
          {open ? (
            <motion.span
              key="x"
              initial={{ rotate: -90, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: 90, opacity: 0 }}
            >
              <X className="h-6 w-6" />
            </motion.span>
          ) : (
            <motion.span
              key="msg"
              initial={{ rotate: 90, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: -90, opacity: 0 }}
            >
              <MessageSquare className="h-6 w-6" />
            </motion.span>
          )}
        </AnimatePresence>
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 30, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.97 }}
            transition={{ duration: 0.25, ease: [0.22, 1, 0.36, 1] }}
            className="fixed bottom-24 right-3 z-50 flex h-[min(640px,80vh)] w-[min(420px,calc(100vw-1.5rem))] flex-col overflow-hidden rounded-3xl border border-stroke glass-strong shadow-2xl shadow-black/50 md:bottom-28 md:right-8"
          >
            <div className="flex items-center gap-3 border-b border-stroke px-4 py-3">
              <div className="relative grid h-9 w-9 place-items-center rounded-full bg-gradient-to-br from-azure to-gold">
                <Sparkles className="h-4 w-4 text-background" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium leading-tight">Adeena's AI</p>
                <p className="text-[11px] text-muted-foreground">Trained on her portfolio</p>
              </div>
              <span className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse-dot" />
                online
              </span>
            </div>

            <div ref={scrollRef} className="flex-1 space-y-3 overflow-y-auto px-4 py-4">
              {messages.map((m) => {
                const text = m.parts
                  .map((p) => (p.type === "text" ? p.text : ""))
                  .join("");
                const mine = m.role === "user";
                return (
                  <div
                    key={m.id}
                    className={`flex ${mine ? "justify-end" : "justify-start"}`}
                  >
                    <div
                      className={`max-w-[85%] whitespace-pre-wrap rounded-2xl px-3.5 py-2.5 text-sm leading-relaxed ${
                        mine
                          ? "rounded-br-sm bg-foreground text-background"
                          : "rounded-bl-sm bg-surface-2 text-foreground"
                      }`}
                    >
                      {text}
                    </div>
                  </div>
                );
              })}
              {isLoading && (
                <div className="flex justify-start">
                  <div className="flex items-center gap-1 rounded-2xl rounded-bl-sm bg-surface-2 px-4 py-3">
                    <span className="h-1.5 w-1.5 rounded-full bg-muted-foreground animate-pulse-dot" />
                    <span className="h-1.5 w-1.5 rounded-full bg-muted-foreground animate-pulse-dot [animation-delay:0.2s]" />
                    <span className="h-1.5 w-1.5 rounded-full bg-muted-foreground animate-pulse-dot [animation-delay:0.4s]" />
                  </div>
                </div>
              )}
            </div>

            {messages.length <= 1 && !leadOpen && (
              <div className="flex flex-wrap gap-1.5 px-4 pb-2">
                {SUGGESTIONS.map((s) => (
                  <button
                    key={s}
                    onClick={() => submit(s)}
                    className="rounded-full border border-stroke bg-surface-2/50 px-2.5 py-1 text-[11px] text-muted-foreground transition-colors hover:border-azure hover:text-foreground"
                  >
                    {s}
                  </button>
                ))}
              </div>
            )}

            {leadOpen && leadState !== "sent" && (
              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  setLeadErr("");
                  setLeadState("sending");
                  const fd = new FormData(e.currentTarget);
                  const payload = {
                    name: String(fd.get("name") ?? "").trim(),
                    email: String(fd.get("email") ?? "").trim(),
                    company: String(fd.get("company") ?? "").trim() || undefined,
                    message: "Lead captured via chatbot",
                    sessionId,
                  };
                  if (!payload.name || !payload.email) {
                    setLeadState("error");
                    setLeadErr("Name and email are required.");
                    return;
                  }
                  try {
                    await submitLeadFn({ data: payload });
                    setLeadState("sent");
                    await sendMessage({
                      text: `Here are my details — Name: ${payload.name}, Company: ${payload.company ?? "—"}, Email: ${payload.email}.`,
                    });
                  } catch (err) {
                    setLeadState("error");
                    setLeadErr(err instanceof Error ? err.message : "Couldn't send.");
                  }
                }}
                className="space-y-2 border-t border-stroke bg-surface-2/40 px-4 py-3"
              >
                <p className="text-[11px] uppercase tracking-[0.25em] text-gold">
                  Share your details
                </p>
                <input
                  name="name"
                  placeholder="Your name"
                  className="w-full rounded-lg bg-background px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-azure/70"
                  required
                />
                <input
                  name="company"
                  placeholder="Company (optional)"
                  className="w-full rounded-lg bg-background px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-azure/70"
                />
                <input
                  name="email"
                  type="email"
                  placeholder="Work email"
                  className="w-full rounded-lg bg-background px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-azure/70"
                  required
                />
                {leadErr && <p className="text-[11px] text-red-400">{leadErr}</p>}
                <div className="flex items-center gap-2 pt-1">
                  <button
                    type="submit"
                    disabled={leadState === "sending"}
                    className="flex-1 rounded-full bg-gradient-to-r from-azure to-gold px-4 py-2 text-xs font-medium text-background disabled:opacity-60"
                  >
                    {leadState === "sending" ? "Sending…" : "Send to Adeena"}
                  </button>
                  <button
                    type="button"
                    onClick={() => setLeadOpen(false)}
                    className="rounded-full border border-stroke px-3 py-2 text-xs text-muted-foreground"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            )}

            {leadState === "sent" && (
              <div className="flex items-center gap-2 border-t border-stroke bg-emerald-500/10 px-4 py-3 text-xs text-emerald-300">
                <CheckCircle2 className="h-4 w-4" /> Details sent — Adeena will be in touch.
              </div>
            )}

            <form
              onSubmit={(e) => {
                e.preventDefault();
                submit(input);
              }}
              className="flex items-center gap-2 border-t border-stroke p-3"
            >
              <button
                type="button"
                onClick={() => setLeadOpen((v) => !v)}
                className="grid h-10 w-10 shrink-0 place-items-center rounded-full border border-stroke text-muted-foreground transition-colors hover:border-gold hover:text-gold"
                aria-label="Share your details"
                title="Share your details"
              >
                <UserPlus className="h-4 w-4" />
              </button>
              <input
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask anything about Adeena…"
                className="flex-1 rounded-full bg-surface-2 px-4 py-2.5 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-azure/70"
                disabled={isLoading}
                maxLength={1000}
              />
              <button
                type="submit"
                disabled={isLoading || !input.trim()}
                className="grid h-10 w-10 place-items-center rounded-full bg-gradient-to-br from-azure to-gold text-background transition-opacity disabled:opacity-50"
                aria-label="Send"
              >
                <Send className="h-4 w-4" />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
