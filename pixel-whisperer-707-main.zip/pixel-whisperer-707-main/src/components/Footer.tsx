import { Link } from "@tanstack/react-router";
import { Github, Linkedin, Mail } from "lucide-react";
import { PROFILE } from "@/lib/portfolio";

export function Footer() {
  return (
    <footer className="relative border-t border-stroke bg-background">
      <div className="mx-auto max-w-7xl px-6 py-12 md:py-16">
        <div className="grid gap-10 md:grid-cols-2 md:items-end">
          <div>
            <p className="font-display text-4xl italic md:text-5xl">
              Let's build something <span className="text-gradient">remarkable</span>.
            </p>
            <p className="mt-3 max-w-md text-sm text-muted-foreground">
              Open to internships, freelance projects, and founder collaborations.
            </p>
            <Link
              to="/contact"
              className="mt-6 inline-flex items-center gap-2 rounded-full bg-foreground px-5 py-3 text-sm font-medium text-background transition-transform hover:scale-[1.03]"
            >
              Start a conversation <span aria-hidden>↗</span>
            </Link>
          </div>
          <div className="flex flex-col gap-4 md:items-end">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <span className="inline-block h-2 w-2 rounded-full bg-emerald-400 animate-pulse-dot" />
              Available for projects
            </div>
            <div className="flex items-center gap-2">
              <a
                href={PROFILE.socials.linkedin}
                target="_blank"
                rel="noreferrer"
                aria-label="LinkedIn"
                className="grid h-10 w-10 place-items-center rounded-full border border-stroke text-muted-foreground transition-colors hover:border-azure hover:text-foreground"
              >
                <Linkedin className="h-4 w-4" />
              </a>
              <a
                href={PROFILE.socials.github}
                target="_blank"
                rel="noreferrer"
                aria-label="GitHub"
                className="grid h-10 w-10 place-items-center rounded-full border border-stroke text-muted-foreground transition-colors hover:border-azure hover:text-foreground"
              >
                <Github className="h-4 w-4" />
              </a>
              <a
                href={`mailto:${PROFILE.email}`}
                aria-label="Email"
                className="grid h-10 w-10 place-items-center rounded-full border border-stroke text-muted-foreground transition-colors hover:border-azure hover:text-foreground"
              >
                <Mail className="h-4 w-4" />
              </a>
            </div>
          </div>
        </div>
        <div className="mt-12 flex flex-col items-start justify-between gap-3 border-t border-stroke pt-6 text-xs text-muted-foreground md:flex-row md:items-center">
          <p>© {new Date().getFullYear()} Adeena. Built with care at IIT Madras.</p>
          <p className="uppercase tracking-[0.25em]">Portfolio · v1</p>
        </div>
      </div>
    </footer>
  );
}
