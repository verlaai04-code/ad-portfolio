import { useCallback, useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, ChevronRight, Pause, Play } from "lucide-react";
import quantum from "@/assets/brands/quantum.jpeg.asset.json";
import zeroTrust from "@/assets/brands/zero-trust.jpeg.asset.json";
import aiDriven from "@/assets/brands/ai-driven.jpeg.asset.json";
import modularAi from "@/assets/brands/modular-ai.jpeg.asset.json";
import cognitive from "@/assets/brands/cognitive-edge.jpeg.asset.json";
import globalMindset from "@/assets/brands/global-mindset.jpeg.asset.json";
import buildTogether from "@/assets/brands/build-together.jpeg.asset.json";

type Slide = { src: string; title: string; caption: string };

const slides: Slide[] = [
  { src: aiDriven.url, title: "AI-Driven Solutions", caption: "Transforming enterprises with next-generation innovation and resilience." },
  { src: quantum.url, title: "Unleash the Power of Quantum", caption: "Next-gen AI to transform data into actionable intelligence." },
  { src: zeroTrust.url, title: "Zero Trust Security", caption: "AI-backed, encrypted, constantly evolving — every request authenticated." },
  { src: modularAi.url, title: "Modular AI Infrastructure", caption: "Systems that think, adapt, evolve — scaling with your enterprise." },
  { src: cognitive.url, title: "Cognitive Edge", caption: "AI meets human intuition — bridging raw data and actionable insight." },
  { src: globalMindset.url, title: "Global Mindset. Local Focus.", caption: "Global expertise with a tailored, impactful approach." },
  { src: buildTogether.url, title: "Let's Build Something Amazing", caption: "Meet the team. Find our footprint." },
];

export function AnantnetraCarousel() {
  const [index, setIndex] = useState(0);
  const [playing, setPlaying] = useState(true);

  const next = useCallback(() => setIndex((i) => (i + 1) % slides.length), []);
  const prev = useCallback(() => setIndex((i) => (i - 1 + slides.length) % slides.length), []);

  useEffect(() => {
    if (!playing) return;
    const t = setInterval(next, 4200);
    return () => clearInterval(t);
  }, [playing, next]);

  const slide = slides[index];

  return (
    <section className="relative py-20 md:py-28">
      <div className="pointer-events-none absolute inset-0 bg-grid opacity-20" />
      <div className="pointer-events-none absolute right-0 top-10 h-80 w-80 rounded-full bg-purple-500/10 blur-3xl" />
      <div className="relative mx-auto max-w-7xl px-6">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7 }}
          className="mb-10 flex flex-col gap-3"
        >
          <div className="flex items-center gap-3">
            <span className="h-px w-8 bg-stroke" />
            <span className="text-[11px] uppercase tracking-[0.3em] text-muted-foreground">
              Anantnetra Technologies · Carousel Series
            </span>
          </div>
          <h2 className="font-display text-4xl leading-tight md:text-6xl">
            Creative direction, slide by <span className="italic text-gradient">slide</span>
          </h2>
          <p className="max-w-2xl text-muted-foreground">
            A LinkedIn carousel series I designed and wrote for Anantnetra
            Technologies — AI, security, and enterprise narrative work.
          </p>
        </motion.div>

        <div className="relative overflow-hidden rounded-3xl border border-stroke bg-surface">
          {/* Stage */}
          <div className="relative aspect-[4/5] w-full sm:aspect-[16/10]">
            <AnimatePresence mode="wait">
              <motion.img
                key={slide.src}
                src={slide.src}
                alt={slide.title}
                initial={{ opacity: 0, scale: 1.04 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
                className="absolute inset-0 h-full w-full object-cover"
              />
            </AnimatePresence>
            <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-background via-background/20 to-transparent" />

            {/* Caption */}
            <div className="absolute inset-x-0 bottom-0 p-6 md:p-10">
              <AnimatePresence mode="wait">
                <motion.div
                  key={slide.title}
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.45 }}
                  className="max-w-2xl"
                >
                  <p className="text-[10px] uppercase tracking-[0.3em] text-white/70">
                    Slide {String(index + 1).padStart(2, "0")} / {String(slides.length).padStart(2, "0")}
                  </p>
                  <h3 className="mt-2 font-display text-2xl leading-tight text-white md:text-4xl">
                    {slide.title}
                  </h3>
                  <p className="mt-2 max-w-xl text-sm text-white/75 md:text-base">
                    {slide.caption}
                  </p>
                </motion.div>
              </AnimatePresence>
            </div>

            {/* Controls */}
            <button
              onClick={prev}
              aria-label="Previous slide"
              className="absolute left-3 top-1/2 inline-flex h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full border border-white/15 bg-black/40 text-white backdrop-blur transition hover:scale-105 hover:bg-black/70 md:left-5"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
            <button
              onClick={next}
              aria-label="Next slide"
              className="absolute right-3 top-1/2 inline-flex h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full border border-white/15 bg-black/40 text-white backdrop-blur transition hover:scale-105 hover:bg-black/70 md:right-5"
            >
              <ChevronRight className="h-5 w-5" />
            </button>
            <button
              onClick={() => setPlaying((p) => !p)}
              aria-label={playing ? "Pause autoplay" : "Resume autoplay"}
              className="absolute right-3 top-3 inline-flex h-9 w-9 items-center justify-center rounded-full border border-white/15 bg-black/50 text-white backdrop-blur transition hover:bg-black/70"
            >
              {playing ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
            </button>
          </div>

          {/* Progress + dots */}
          <div className="flex items-center justify-between gap-4 border-t border-stroke bg-background/60 px-4 py-3 md:px-6">
            <div className="flex flex-1 items-center gap-1.5">
              {slides.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setIndex(i)}
                  aria-label={`Go to slide ${i + 1}`}
                  className={`h-1 flex-1 overflow-hidden rounded-full transition ${
                    i === index ? "bg-white/15" : "bg-white/5 hover:bg-white/10"
                  }`}
                >
                  {i === index && (
                    <motion.span
                      key={`bar-${index}-${playing}`}
                      initial={{ width: "0%" }}
                      animate={{ width: playing ? "100%" : "100%" }}
                      transition={{ duration: playing ? 4.2 : 0.2, ease: "linear" }}
                      className="block h-full bg-gradient-to-r from-azure to-gold"
                    />
                  )}
                </button>
              ))}
            </div>
            <span className="text-[10px] uppercase tracking-[0.25em] text-muted-foreground">
              Anantnetra · {String(index + 1).padStart(2, "0")}
            </span>
          </div>
        </div>

        {/* Thumbnails */}
        <div className="mt-5 grid grid-cols-4 gap-2 sm:grid-cols-7">
          {slides.map((s, i) => (
            <button
              key={s.src}
              onClick={() => setIndex(i)}
              className={`group relative aspect-[4/5] overflow-hidden rounded-xl border transition ${
                i === index ? "border-azure ring-2 ring-azure/40" : "border-stroke hover:border-white/30"
              }`}
              aria-label={`Show ${s.title}`}
            >
              <img
                src={s.src}
                alt={s.title}
                loading="lazy"
                className="absolute inset-0 h-full w-full object-cover opacity-80 transition group-hover:opacity-100"
              />
              <span className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 to-transparent p-1.5 text-left text-[9px] uppercase tracking-wider text-white/85">
                {String(i + 1).padStart(2, "0")}
              </span>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}
