import { useEffect, useRef, useState } from "react";
import { Volume2, VolumeX } from "lucide-react";

interface Props {
  src: string;
  poster?: string;
  className?: string;
  hoverPlay?: boolean;
  autoPlay?: boolean;
  loop?: boolean;
  controls?: boolean;
}

export function VideoPlayer({
  src,
  className,
  hoverPlay = false,
  autoPlay = false,
  loop = true,
  controls = false,
  poster,
}: Props) {
  const ref = useRef<HTMLVideoElement>(null);
  const [visible, setVisible] = useState(false);
  const [muted, setMuted] = useState(true);

  useEffect(() => {
    const el = ref.current;
    if (!el || !autoPlay) return;
    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) {
            el.play().catch(() => {});
            setVisible(true);
          } else {
            el.pause();
          }
        }
      },
      { threshold: 0.35 },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [autoPlay]);

  const toggleMute = () => {
    const el = ref.current;
    if (!el) return;
    const next = !muted;
    el.muted = next;
    setMuted(next);
    if (!next) el.play().catch(() => {});
  };

  return (
    <div className="relative h-full w-full">
      <video
        ref={ref}
        src={src}
        poster={poster}
        muted={muted}
        playsInline
        loop={loop}
        controls={controls}
        preload="metadata"
        className={className}
        onMouseEnter={hoverPlay ? () => ref.current?.play().catch(() => {}) : undefined}
        onMouseLeave={hoverPlay ? () => ref.current?.pause() : undefined}
        data-visible={visible}
      />
      <button
        type="button"
        onClick={toggleMute}
        aria-label={muted ? "Unmute video" : "Mute video"}
        className="absolute bottom-3 right-3 z-10 inline-flex h-9 w-9 items-center justify-center rounded-full border border-white/15 bg-black/55 text-white backdrop-blur transition hover:scale-105 hover:bg-black/75"
      >
        {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
      </button>
    </div>
  );
}
