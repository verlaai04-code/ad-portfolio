// Centralized video asset imports.
import heroVideo from "@/assets/WhatsApp_Video_2026-06-21_at_10.39.31_PM.mp4.asset.json";
import tamilLlmVideo from "@/assets/WhatsApp_Video_2026-06-21_at_8.49.43_PM.mp4.asset.json";
import contentStudioVideo from "@/assets/WhatsApp_Video_2026-06-21_at_8.49.44_PM.mp4.asset.json";
import ritzCarltonVideo from "@/assets/WhatsApp_Video_2026-06-21_at_8.49.44_PM_1.mp4.asset.json";
import ritzParisVideo from "@/assets/WhatsApp_Video_2026-06-21_at_8.50.32_PM.mp4.asset.json";
import ugcVideo from "@/assets/WhatsApp_Video_2026-06-21_at_8.51.38_PM.mp4.asset.json";

export const VIDEOS = {
  hero: heroVideo.url,
  // Corrected mapping per portfolio owner:
  // - StudyFlow LLM uses what was previously labeled the "ugc" file
  // - UGC portfolio uses what was previously the "tamilLlm" file
  // - Content Studio uses the standalone 8.50.32 PM file
  // - Ritz-Carlton uses the 8.49.44 PM file
  // - Ritz Paris uses the 8.49.44 PM_1 file
  tamilLlm: ugcVideo.url,
  ugc: tamilLlmVideo.url,
  contentStudio: ritzParisVideo.url,
  ritzCarlton: contentStudioVideo.url,
  ritzParis: ritzCarltonVideo.url,
};
