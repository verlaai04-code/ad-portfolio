import { VIDEOS } from "./assets";

export const PROFILE = {
  name: "Adeena",
  title: "IIT Madras Student · AI Builder · Digital Marketer · Founder, Velra AI",
  short:
    "IIT Madras student and founder of Velra AI — building AI products, lead capture & qualification, workflow automation, and email automation systems for growing teams.",
  email: "hello@adeena.dev",
  socials: {
    linkedin: "https://www.linkedin.com/in/adeena-siddiqua-709612346/",
    github: "https://github.com",
    velra: "https://velra-ai-ascent.vercel.app/",
  },
};

export const SKILLS = [
  "Lead Capture",
  "Lead Qualification",
  "Workflow Automation",
  "Email Automation",
  "AI Automation",
  "Frontend Development",
  "React",
  "Tailwind CSS",
  "Digital Marketing",
  "MVP Building",
  "Content Creation",
  "Video Editing",
];

export const CERT_CATEGORIES = [
  { name: "Frontend Development", count: 6, accent: "azure" },
  { name: "Technology", count: 4, accent: "gold" },
  { name: "IoT", count: 3, accent: "azure" },
  { name: "Coding", count: 5, accent: "gold" },
  { name: "Digital Marketing", count: 4, accent: "azure" },
];

export type Project = {
  slug: string;
  title: string;
  blurb: string;
  tech: string[];
  features: string[];
  video?: string;
  liveUrl?: string;
  githubUrl?: string;
  category: string;
};

export const PROJECTS: Project[] = [
  {
    slug: "ai-portfolio-chatbot",
    title: "AI Portfolio Chatbot",
    blurb:
      "A conversational AI trained on my portfolio that answers recruiter questions and captures leads.",
    tech: ["React", "TanStack Start", "Lovable AI", "Postgres"],
    features: ["Streaming responses", "Lead capture", "Persistent chat history"],
    category: "AI",
    githubUrl: "#",
  },
  {
    slug: "studyflow-tn-llm",
    title: "StudyFlow — Tamil Nadu Board LLM",
    blurb:
      "An LLM-powered study companion built for 12th-standard Tamil Nadu Board students, tailored to their syllabus.",
    tech: ["Next.js", "OpenAI", "RAG", "Tailwind"],
    features: ["Subject-aware tutoring", "Past-paper drilling", "Tamil + English"],
    video: VIDEOS.tamilLlm,
    category: "AI",
    liveUrl: "#",
  },
  {
    slug: "content-studio",
    title: "Content Studio",
    blurb:
      "Tailors my content daily — repurposes ideas into reels, threads, and posts using a custom AI pipeline.",
    tech: ["AI Agents", "Automation", "Notion API"],
    features: ["Daily content batch", "Platform-aware formatting", "Hook generator"],
    video: VIDEOS.contentStudio,
    category: "AI Automation",
    liveUrl: "#",
  },
  {
    slug: "studytime",
    title: "StudyTime",
    blurb:
      "A focus-first time tracking app for students who want to see exactly where their hours go.",
    tech: ["React", "PWA", "IndexedDB"],
    features: ["Pomodoro", "Subject analytics", "Streaks"],
    category: "Product",
    liveUrl: "#",
  },
  {
    slug: "ritz-carlton-campaign",
    title: "Ritz-Carlton — Freelance Campaign",
    blurb:
      "Concepted, shot and edited a hospitality-grade UGC piece for a Ritz-Carlton brand collaboration.",
    tech: ["Video Editing", "UGC", "Brand Strategy"],
    features: ["Hero edit", "Multi-platform cuts", "On-brand grade"],
    video: VIDEOS.ritzCarlton,
    category: "Freelance",
  },
  {
    slug: "ritz-paris-campaign",
    title: "Ritz Paris — Freelance Campaign",
    blurb:
      "Luxury-tone storytelling piece produced for a Ritz Paris freelance project.",
    tech: ["Cinematic Edit", "Color", "Sound Design"],
    features: ["Story-first edit", "Color matched to brand", "Reel + landscape"],
    video: VIDEOS.ritzParis,
    category: "Freelance",
  },
  {
    slug: "ugc-portfolio",
    title: "UGC Portfolio",
    blurb:
      "A short-form UGC piece from my creator portfolio — concept to final cut.",
    tech: ["UGC", "Story", "Edit"],
    features: ["Hook in 2s", "Native vertical", "Brand-safe"],
    video: VIDEOS.ugc,
    category: "Content",
  },
  {
    slug: "velra-ai",
    title: "Velra AI — Automation Agency",
    blurb:
      "My AI automation agency. We build lead capture, lead qualification, workflow automation, and email automation systems for growing teams.",
    tech: ["AI Agents", "n8n", "OpenAI", "Email Automation"],
    features: [
      "Lead capture funnels",
      "AI lead qualification",
      "Workflow automation",
      "Email automation sequences",
    ],
    category: "Agency",
    liveUrl: "https://velra-ai-ascent.vercel.app/",
  },
  {
    slug: "ai-automation-agency",
    title: "AI Automation Agency Stack",
    blurb:
      "Inbound bot, CRM sync, and reporting stack — the engine behind Velra AI's client work.",
    tech: ["n8n", "OpenAI", "Zapier", "Make"],
    features: ["Inbound bot", "CRM sync", "Reporting"],
    category: "Agency",
  },
  {
    slug: "wedding-rsvp",
    title: "Wedding RSVP & Management MVP",
    blurb:
      "End-to-end wedding RSVP + guest management MVP — invites, tracking, and live counts.",
    tech: ["React", "Supabase", "Stripe"],
    features: ["Invite links", "Guest list", "Real-time RSVP"],
    category: "MVP",
  },
];

export const ACHIEVEMENTS = [
  { value: "3+", label: "MVP products built" },
  { value: "10+", label: "Websites delivered" },
  { value: "21k+", label: "YouTube views" },
  { value: "15%", label: "Engagement lift in 15 days" },
];

export const CASE_STUDY = {
  title: "Jewelry Brand Growth Campaign",
  summary:
    "Led a 15-day social campaign for a regional jewelry brand — repositioned the feed, scripted UGC, and ran a content cadence test.",
  metrics: [
    { label: "Engagement lift", value: 15, suffix: "%" },
    { label: "Days to results", value: 15, suffix: "d" },
    { label: "Audience interaction", value: 2.4, suffix: "x" },
  ],
};
