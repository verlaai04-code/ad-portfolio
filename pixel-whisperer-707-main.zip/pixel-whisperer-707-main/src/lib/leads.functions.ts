import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";
import type { Database } from "@/integrations/supabase/types";

const LeadSchema = z.object({
  name: z.string().trim().min(1).max(100),
  email: z.string().trim().email().max(255),
  company: z.string().trim().max(150).optional().nullable(),
  message: z.string().trim().max(2000).optional().nullable(),
  sessionId: z.string().uuid().optional().nullable(),
});

const SHEET_WEBHOOK =
  "https://script.google.com/macros/s/AKfycbzh0Lw7FSbLUEepTC99hDY5ia_0GQtAlDGuss_FO8CqkEKA65nlnbc3u_8Bf1ZsMdKf/exec";

export const submitLead = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => LeadSchema.parse(input))
  .handler(async ({ data }) => {
    const supabase = createClient<Database>(
      process.env.SUPABASE_URL!,
      process.env.SUPABASE_PUBLISHABLE_KEY!,
      { auth: { storage: undefined, persistSession: false, autoRefreshToken: false } },
    );
    const { error } = await supabase.from("leads").insert({
      name: data.name,
      email: data.email,
      company: data.company ?? null,
      message: data.message ?? null,
      session_id: data.sessionId ?? null,
    });
    if (error) {
      console.error("[leads] insert error", error);
      throw new Error("Failed to submit. Please try again.");
    }

    try {
      await fetch(SHEET_WEBHOOK, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: data.name,
          email: data.email,
          company: data.company ?? "",
          message: data.message ?? "",
          sessionId: data.sessionId ?? "",
          source: data.sessionId ? "chatbot" : "contact_form",
          timestamp: new Date().toISOString(),
        }),
      });
    } catch (e) {
      console.error("[leads] sheet webhook failed", e);
    }
    return { ok: true };
  });
