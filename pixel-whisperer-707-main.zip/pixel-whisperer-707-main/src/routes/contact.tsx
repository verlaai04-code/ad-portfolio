import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { motion } from "framer-motion";
import { CheckCircle2, Send } from "lucide-react";
import { useState } from "react";
import { z } from "zod";
import { submitLead } from "@/lib/leads.functions";
import { PROFILE } from "@/lib/portfolio";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact Adeena — Let's build something" },
      {
        name: "description",
        content:
          "Get in touch with Adeena for internships, freelance work, or collaborations.",
      },
      { property: "og:title", content: "Contact Adeena" },
      {
        property: "og:description",
        content: "Send a message to start a conversation.",
      },
    ],
  }),
  component: ContactPage,
});

const Schema = z.object({
  name: z.string().trim().min(1, "Name is required").max(100),
  email: z.string().trim().email("Valid email required").max(255),
  company: z.string().trim().max(150).optional(),
  message: z.string().trim().min(1, "Tell me a bit about it").max(2000),
});

function ContactPage() {
  const submit = useServerFn(submitLead);
  const [state, setState] = useState<"idle" | "sending" | "sent" | "error">("idle");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [errorMsg, setErrorMsg] = useState("");

  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setErrors({});
    setErrorMsg("");
    const fd = new FormData(e.currentTarget);
    const data = {
      name: String(fd.get("name") ?? ""),
      email: String(fd.get("email") ?? ""),
      company: String(fd.get("company") ?? "") || undefined,
      message: String(fd.get("message") ?? ""),
    };
    const parsed = Schema.safeParse(data);
    if (!parsed.success) {
      const fe: Record<string, string> = {};
      for (const issue of parsed.error.issues) {
        const k = String(issue.path[0] ?? "");
        if (k && !fe[k]) fe[k] = issue.message;
      }
      setErrors(fe);
      return;
    }
    setState("sending");
    try {
      await submit({ data: parsed.data });
      setState("sent");
      (e.target as HTMLFormElement).reset();
    } catch (err) {
      setState("error");
      setErrorMsg(err instanceof Error ? err.message : "Something went wrong");
    }
  };

  return (
    <div className="relative pt-32 md:pt-40">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-[500px] bg-gradient-to-b from-azure/10 to-transparent" />
      <section className="mx-auto grid max-w-6xl gap-12 px-6 pb-32 md:grid-cols-12 md:gap-16">
        <div className="md:col-span-5">
          <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">
            Contact
          </p>
          <h1 className="mt-4 font-display text-5xl leading-[1] md:text-7xl">
            Let's <span className="italic text-gradient">talk</span>.
          </h1>
          <p className="mt-6 text-muted-foreground md:text-lg">
            Internship, freelance project, or just a hello — drop me a line and
            I'll reply within 48 hours.
          </p>
          <dl className="mt-10 space-y-5 text-sm">
            <div>
              <dt className="text-[11px] uppercase tracking-[0.25em] text-muted-foreground">
                Email
              </dt>
              <dd className="mt-1">
                <a
                  href={`mailto:${PROFILE.email}`}
                  className="text-foreground underline decoration-azure underline-offset-4 hover:decoration-gold"
                >
                  {PROFILE.email}
                </a>
              </dd>
            </div>
            <div>
              <dt className="text-[11px] uppercase tracking-[0.25em] text-muted-foreground">
                Based in
              </dt>
              <dd className="mt-1 text-foreground">Chennai · IIT Madras</dd>
            </div>
            <div>
              <dt className="text-[11px] uppercase tracking-[0.25em] text-muted-foreground">
                Available for
              </dt>
              <dd className="mt-1 text-foreground">
                Internships · Freelance · Founder collaborations
              </dd>
            </div>
          </dl>
        </div>

        <motion.form
          onSubmit={onSubmit}
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          className="relative md:col-span-7"
        >
          <div className="pointer-events-none absolute -inset-2 rounded-[2rem] bg-gradient-to-br from-azure/30 to-gold/20 opacity-50 blur-2xl" />
          <div className="relative space-y-5 rounded-3xl border border-stroke glass-strong p-6 md:p-10">
            <Field label="Your name" error={errors.name}>
              <input
                name="name"
                maxLength={100}
                className="w-full rounded-xl border border-stroke bg-background/50 px-4 py-3 text-sm placeholder:text-muted-foreground focus:border-azure focus:outline-none"
                placeholder="Jane Doe"
              />
            </Field>
            <Field label="Email" error={errors.email}>
              <input
                name="email"
                type="email"
                maxLength={255}
                className="w-full rounded-xl border border-stroke bg-background/50 px-4 py-3 text-sm placeholder:text-muted-foreground focus:border-azure focus:outline-none"
                placeholder="jane@company.com"
              />
            </Field>
            <Field label="Company (optional)">
              <input
                name="company"
                maxLength={150}
                className="w-full rounded-xl border border-stroke bg-background/50 px-4 py-3 text-sm placeholder:text-muted-foreground focus:border-azure focus:outline-none"
                placeholder="Acme Co."
              />
            </Field>
            <Field label="Message" error={errors.message}>
              <textarea
                name="message"
                rows={5}
                maxLength={2000}
                className="w-full resize-none rounded-xl border border-stroke bg-background/50 px-4 py-3 text-sm placeholder:text-muted-foreground focus:border-azure focus:outline-none"
                placeholder="Tell me about your project, role, or idea…"
              />
            </Field>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                type="submit"
                disabled={state === "sending"}
                className="inline-flex items-center gap-2 rounded-full bg-foreground px-6 py-3 text-sm font-medium text-background transition-transform hover:scale-[1.03] disabled:opacity-60"
              >
                {state === "sending" ? "Sending…" : "Send message"}
                <Send className="h-4 w-4" />
              </button>
              <a
                href={`mailto:${PROFILE.email}?subject=Quick%20intro`}
                className="inline-flex items-center rounded-full border border-stroke px-5 py-3 text-sm hover:border-azure"
              >
                Schedule meeting
              </a>
              {state === "sent" && (
                <span className="inline-flex items-center gap-1.5 text-sm text-emerald-400">
                  <CheckCircle2 className="h-4 w-4" /> Thanks — I'll be in touch.
                </span>
              )}
              {state === "error" && (
                <span className="text-sm text-red-400">{errorMsg || "Could not send"}</span>
              )}
            </div>
          </div>
        </motion.form>
      </section>
    </div>
  );
}

function Field({
  label,
  error,
  children,
}: {
  label: string;
  error?: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-[11px] uppercase tracking-[0.25em] text-muted-foreground">
        {label}
      </span>
      {children}
      {error && <span className="mt-1 block text-xs text-red-400">{error}</span>}
    </label>
  );
}
