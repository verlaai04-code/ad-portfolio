import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { ArrowUpRight, Sparkles, Cpu, Rocket } from "lucide-react";
import { VideoPlayer } from "@/components/VideoPlayer";
import { VIDEOS } from "@/lib/assets";
import { PROFILE, SKILLS, ACHIEVEMENTS, PROJECTS, CASE_STUDY } from "@/lib/portfolio";
import { YouTubeAnalytics } from "@/components/YouTubeAnalytics";
import { BrandsVentures } from "@/components/BrandsVentures";
import { AnantnetraCarousel } from "@/components/AnantnetraCarousel";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Adeena — IIT Madras · AI Builder · Digital Marketer" },
      {
        name: "description",
        content:
          "Portfolio of Adeena — IIT Madras student building AI products, websites, and high-performing digital campaigns.",
      },
      { property: "og:title", content: "Adeena — Portfolio" },
      {
        property: "og:description",
        content:
          "AI products, MVPs, and brand campaigns by an IIT Madras student.",
      },
    ],
  }),
  component: Home,
});

const fadeUp = {
  initial: { opacity: 0, y: 24 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: "-80px" },
  transition: { duration: 0.7, ease: [0.22, 1, 0.36, 1] as const },
};

function Home() {
  // Curated featured: ensure horizontal 2nd slot is the UGC video
  const featured = [
    PROJECTS.find((p) => p.slug === "studyflow-tn-llm")!,
    PROJECTS.find((p) => p.slug === "ugc-portfolio")!,
    PROJECTS.find((p) => p.slug === "content-studio")!,
    PROJECTS.find((p) => p.slug === "ritz-paris-campaign")!,
  ];
  return (
    <>
      <Hero />
      <Marquee />
      <AboutTeaser />
      <Featured projects={featured} />
      <BrandsVentures />
      <AnantnetraCarousel />
      <YouTubeAnalytics />
      <CaseStudyBlock />
      <Stats />
    </>
  );
}


function Hero() {
  return (
    <section className="relative min-h-screen overflow-hidden pt-28 md:pt-32">
      {/* Background grid + glows */}
      <div className="pointer-events-none absolute inset-0 bg-grid opacity-40" />
      <div className="pointer-events-none absolute -left-40 top-20 h-96 w-96 rounded-full bg-azure/20 blur-3xl" />
      <div className="pointer-events-none absolute -right-32 top-1/3 h-[28rem] w-[28rem] rounded-full bg-gold/15 blur-3xl" />

      <div className="relative mx-auto grid max-w-7xl gap-12 px-6 pb-20 md:grid-cols-12 md:items-center md:gap-10 md:pb-28">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
          className="md:col-span-7"
        >
          <span className="inline-flex items-center gap-2 rounded-full border border-stroke bg-surface/60 px-3 py-1 text-[11px] uppercase tracking-[0.3em] text-muted-foreground">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse-dot" />
            Open for opportunities
          </span>
          <h1 className="mt-6 font-display text-5xl leading-[0.95] tracking-tight md:text-7xl lg:text-8xl">
            Hi, I'm <span className="italic text-gradient">{PROFILE.name}</span>
          </h1>
          <p className="mt-5 max-w-xl text-base text-muted-foreground md:text-lg">
            {PROFILE.title}. I build AI products, ship MVPs, and run digital
            campaigns that actually move the needle.
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <Link
              to="/projects"
              className="group inline-flex items-center gap-2 rounded-full bg-foreground px-6 py-3 text-sm font-medium text-background transition-transform hover:scale-[1.03]"
            >
              View Portfolio
              <ArrowUpRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </Link>
            <button
              type="button"
              onClick={() => {
                document
                  .querySelector<HTMLButtonElement>('[aria-label*="chat" i]')
                  ?.click();
              }}
              className="group relative inline-flex items-center gap-2 rounded-full px-6 py-3 text-sm font-medium"
            >
              <span className="absolute inset-0 rounded-full border border-stroke transition-colors group-hover:border-transparent" />
              <span className="absolute -inset-[1.5px] rounded-full bg-gradient-to-r from-azure to-gold opacity-0 transition-opacity group-hover:opacity-100 animate-gradient" />
              <span className="relative inline-flex items-center gap-2 rounded-full bg-background px-5 py-2.5">
                <Sparkles className="h-4 w-4 text-gold" />
                Chat with my AI
              </span>
            </button>
          </div>

          {/* Quick credentials */}
          <div className="mt-12 grid max-w-md grid-cols-3 gap-6 border-t border-stroke pt-6 text-left">
            {[
              { k: "IIT", v: "Madras" },
              { k: "21k+", v: "Views" },
              { k: "3+", v: "MVPs" },
            ].map((c) => (
              <div key={c.k}>
                <p className="font-display text-2xl text-foreground md:text-3xl">{c.k}</p>
                <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">{c.v}</p>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Intro video card */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 40 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
          className="relative md:col-span-5"
        >
          <div className="relative mx-auto aspect-[3/4] w-full max-w-sm">
            <div className="absolute -inset-2 rounded-[2rem] bg-gradient-to-br from-azure/40 via-transparent to-gold/30 blur-2xl" />
            <div className="relative h-full w-full overflow-hidden rounded-[2rem] border border-stroke glass-strong">
              <VideoPlayer
                src={VIDEOS.hero}
                autoPlay
                loop
                className="h-full w-full object-cover"
              />
              <div className="pointer-events-none absolute inset-x-0 bottom-0 h-32 bg-gradient-to-t from-background/90 to-transparent" />
              <div className="absolute bottom-4 left-4 right-4">
                <p className="text-[11px] uppercase tracking-[0.3em] text-muted-foreground">
                  Intro
                </p>
                <p className="font-display text-xl italic text-foreground">
                  Hello, world.
                </p>
              </div>
            </div>
            {/* floating chips */}
            <div className="absolute -left-6 top-12 hidden rounded-2xl border border-stroke bg-surface/90 px-3 py-2 text-xs backdrop-blur md:block animate-float">
              <Cpu className="mb-1 h-3.5 w-3.5 text-azure" />
              <p className="font-medium">AI · Automation</p>
            </div>
            <div
              className="absolute -right-6 bottom-24 hidden rounded-2xl border border-stroke bg-surface/90 px-3 py-2 text-xs backdrop-blur md:block animate-float"
              style={{ animationDelay: "1.2s" }}
            >
              <Rocket className="mb-1 h-3.5 w-3.5 text-gold" />
              <p className="font-medium">Ship MVPs fast</p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

function Marquee() {
  const items = [...SKILLS, ...SKILLS];
  return (
    <div className="border-y border-stroke bg-surface/40 py-5 overflow-hidden">
      <div className="flex animate-[scroll_45s_linear_infinite] gap-10 whitespace-nowrap">
        {items.map((s, i) => (
          <span
            key={`${s}-${i}`}
            className="font-display text-xl italic text-muted-foreground md:text-2xl"
          >
            {s} <span className="mx-6 text-gold">✦</span>
          </span>
        ))}
      </div>
      <style>{`@keyframes scroll { to { transform: translateX(-50%) } }`}</style>
    </div>
  );
}

function AboutTeaser() {
  return (
    <section className="relative mx-auto max-w-7xl px-6 py-24 md:py-32">
      <motion.div {...fadeUp} className="grid gap-10 md:grid-cols-12">
        <div className="md:col-span-5">
          <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">About</p>
          <h2 className="mt-4 font-display text-4xl leading-tight md:text-6xl">
            Building at the <span className="italic text-gradient">intersection</span>
            <br />of tech & business.
          </h2>
        </div>
        <div className="md:col-span-7 md:pl-10">
          <p className="text-lg text-foreground/85 md:text-xl">
            I'm an IIT Madras student passionate about AI, automation, digital
            marketing, and building MVP products. I enjoy creating solutions that
            combine technology and business growth — from{" "}
            <span className="text-foreground">LLM-powered study tools</span> to{" "}
            <span className="text-foreground">brand campaigns for hospitality</span>.
          </p>
          <div className="mt-8 flex flex-wrap gap-2">
            {SKILLS.slice(0, 8).map((s) => (
              <span
                key={s}
                className="rounded-full border border-stroke bg-surface px-3 py-1.5 text-xs text-muted-foreground"
              >
                {s}
              </span>
            ))}
          </div>
          <Link
            to="/about"
            className="mt-10 inline-flex items-center gap-2 text-sm text-foreground underline decoration-azure decoration-2 underline-offset-4 hover:decoration-gold"
          >
            Full story <ArrowUpRight className="h-4 w-4" />
          </Link>
        </div>
      </motion.div>
    </section>
  );
}

function Featured({ projects }: { projects: typeof PROJECTS }) {
  return (
    <section className="relative bg-surface/30 py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-6">
        <motion.div {...fadeUp} className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">
              Selected Work
            </p>
            <h2 className="mt-3 font-display text-4xl md:text-6xl">
              Featured <span className="italic text-gradient">projects</span>
            </h2>
          </div>
          <Link
            to="/projects"
            className="group inline-flex items-center gap-2 rounded-full border border-stroke px-5 py-2.5 text-sm transition-colors hover:border-azure"
          >
            View all
            <ArrowUpRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
          </Link>
        </motion.div>

        <div className="mt-12 grid gap-6 md:grid-cols-12">
          {projects.map((p, i) => (
            <motion.article
              key={p.slug}
              {...fadeUp}
              transition={{ ...fadeUp.transition, delay: i * 0.05 }}
              className={`group relative overflow-hidden rounded-3xl border border-stroke bg-surface ${
                i % 4 === 0 || i % 4 === 3 ? "md:col-span-7" : "md:col-span-5"
              }`}
            >
              <div className="relative aspect-[16/10] overflow-hidden">
                {p.video ? (
                  <VideoPlayer
                    src={p.video}
                    autoPlay
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                ) : (
                  <div className="grid h-full w-full place-items-center bg-gradient-to-br from-surface-2 via-surface to-background">
                    <span className="font-display text-7xl italic text-muted-foreground/50">
                      {p.title.charAt(0)}
                    </span>
                  </div>
                )}
                <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-background/90 via-background/20 to-transparent" />
              </div>
              <div className="absolute inset-x-0 bottom-0 p-6 md:p-7">
                <p className="text-[11px] uppercase tracking-[0.3em] text-gold">
                  {p.category}
                </p>
                <h3 className="mt-2 font-display text-2xl md:text-3xl">{p.title}</h3>
                <p className="mt-2 line-clamp-2 max-w-md text-sm text-muted-foreground">
                  {p.blurb}
                </p>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}

function CaseStudyBlock() {
  return (
    <section className="relative mx-auto max-w-7xl px-6 py-24 md:py-32">
      <motion.div
        {...fadeUp}
        className="relative overflow-hidden rounded-3xl border border-stroke bg-gradient-to-br from-surface to-background p-8 md:p-14"
      >
        <div className="pointer-events-none absolute -right-20 -top-20 h-72 w-72 rounded-full bg-gold/20 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-24 -left-12 h-72 w-72 rounded-full bg-azure/20 blur-3xl" />
        <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">Case Study</p>
        <h2 className="mt-3 max-w-2xl font-display text-3xl leading-tight md:text-5xl">
          {CASE_STUDY.title}
        </h2>
        <p className="mt-4 max-w-2xl text-muted-foreground md:text-lg">
          {CASE_STUDY.summary}
        </p>
        <div className="mt-10 grid gap-6 sm:grid-cols-3">
          {CASE_STUDY.metrics.map((m) => (
            <div
              key={m.label}
              className="rounded-2xl border border-stroke bg-background/40 p-6 backdrop-blur"
            >
              <p className="font-display text-5xl text-gradient">
                {m.value}
                <span className="text-foreground/80">{m.suffix}</span>
              </p>
              <p className="mt-2 text-xs uppercase tracking-[0.25em] text-muted-foreground">
                {m.label}
              </p>
            </div>
          ))}
        </div>
      </motion.div>
    </section>
  );
}

function Stats() {
  return (
    <section className="border-t border-stroke bg-background py-20 md:py-28">
      <div className="mx-auto grid max-w-7xl gap-10 px-6 sm:grid-cols-2 md:grid-cols-4">
        {ACHIEVEMENTS.map((a, i) => (
          <motion.div
            key={a.label}
            {...fadeUp}
            transition={{ ...fadeUp.transition, delay: i * 0.05 }}
          >
            <p className="font-display text-6xl text-foreground">{a.value}</p>
            <p className="mt-2 text-sm text-muted-foreground">{a.label}</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
