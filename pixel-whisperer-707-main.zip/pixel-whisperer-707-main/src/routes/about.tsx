import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { ArrowUpRight, Award, GraduationCap, Sparkles } from "lucide-react";
import { CERT_CATEGORIES, PROFILE, SKILLS } from "@/lib/portfolio";
import { Achievements } from "@/components/Achievements";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About Adeena — IIT Madras Student & AI Builder" },
      {
        name: "description",
        content:
          "Adeena is an IIT Madras student building AI products, automation tools, and digital marketing campaigns.",
      },
      { property: "og:title", content: "About Adeena" },
      {
        property: "og:description",
        content: "IIT Madras student building at the intersection of AI and business.",
      },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <div className="relative pt-32 md:pt-40">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-[600px] bg-gradient-to-b from-azure/5 to-transparent" />
      <section className="mx-auto max-w-5xl px-6 pb-20">
        <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">About</p>
        <h1 className="mt-4 font-display text-5xl leading-tight md:text-7xl">
          The story behind <span className="italic text-gradient">the work</span>.
        </h1>
        <p className="mt-8 max-w-2xl text-lg text-foreground/85 md:text-xl">
          {PROFILE.short} Whether it's a brand campaign for a luxury hotel or an
          LLM tuned for 12th-standard Tamil Nadu students, the principle is the
          same — make something useful, and ship it.
        </p>
      </section>

      {/* Bio card */}
      <section className="mx-auto max-w-5xl px-6 pb-20">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="grid gap-6 rounded-3xl border border-stroke bg-surface/60 p-8 md:grid-cols-3 md:p-10"
        >
          <div>
            <GraduationCap className="h-5 w-5 text-azure" />
            <p className="mt-3 text-xs uppercase tracking-[0.25em] text-muted-foreground">
              Education
            </p>
            <p className="mt-1 text-foreground">IIT Madras</p>
          </div>
          <div>
            <Sparkles className="h-5 w-5 text-gold" />
            <p className="mt-3 text-xs uppercase tracking-[0.25em] text-muted-foreground">
              Focus
            </p>
            <p className="mt-1 text-foreground">AI · MVPs · Growth</p>
          </div>
          <div>
            <Award className="h-5 w-5 text-azure" />
            <p className="mt-3 text-xs uppercase tracking-[0.25em] text-muted-foreground">
              Currently
            </p>
            <p className="mt-1 text-foreground">Open for internships & freelance</p>
          </div>
        </motion.div>
      </section>

      {/* Skills */}
      <section className="mx-auto max-w-5xl px-6 pb-20">
        <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">Skills</p>
        <h2 className="mt-3 font-display text-3xl md:text-5xl">
          What I <span className="italic text-gradient">work with</span>
        </h2>
        <div className="mt-8 flex flex-wrap gap-2.5">
          {SKILLS.map((s, i) => (
            <motion.span
              key={s}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.03 }}
              className="rounded-full border border-stroke bg-surface px-4 py-2 text-sm text-foreground/90 transition-colors hover:border-azure hover:text-foreground"
            >
              {s}
            </motion.span>
          ))}
        </div>
      </section>

      <Achievements />

      {/* Certifications */}
      <section className="mx-auto max-w-5xl px-6 pb-24">
        <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">
          Certifications
        </p>
        <h2 className="mt-3 font-display text-3xl md:text-5xl">
          Always <span className="italic text-gradient">learning</span>
        </h2>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {CERT_CATEGORIES.map((c) => (
            <motion.div
              key={c.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="group relative overflow-hidden rounded-2xl border border-stroke bg-surface p-6"
            >
              <div
                className={`absolute -right-10 -top-10 h-28 w-28 rounded-full blur-2xl transition-opacity group-hover:opacity-80 ${
                  c.accent === "azure" ? "bg-azure/30" : "bg-gold/30"
                } opacity-40`}
              />
              <p className="relative font-display text-3xl">{c.count}+</p>
              <p className="relative mt-1 text-sm text-foreground/90">{c.name}</p>
              <p className="relative mt-3 text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
                Certified
              </p>
            </motion.div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-5xl px-6 pb-32">
        <div className="rounded-3xl border border-stroke bg-gradient-to-br from-surface to-background p-8 text-center md:p-14">
          <h3 className="font-display text-3xl md:text-5xl">
            Want to work together?
          </h3>
          <Link
            to="/contact"
            className="mt-6 inline-flex items-center gap-2 rounded-full bg-foreground px-6 py-3 text-sm font-medium text-background hover:scale-[1.03] transition-transform"
          >
            Get in touch <ArrowUpRight className="h-4 w-4" />
          </Link>
        </div>
      </section>
    </div>
  );
}
