import { createFileRoute } from "@tanstack/react-router";
import { createLovableAiGatewayProvider } from "@/lib/ai-gateway.server";
import { convertToModelMessages, streamText, type UIMessage } from "ai";
import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";

const SYSTEM_PROMPT = `You are "Adeena's AI" — a warm, sharp portfolio assistant for Adeena, an IIT Madras student, AI builder, digital marketer, and web developer.

Your jobs, in order:
1. Answer questions about Adeena's skills, projects, experience, certifications, and achievements (use the FACTS below).
2. When a recruiter, HR, or founder seems interested (mentions hiring, role, opportunity, internship, collab, project, "can we talk", "are you available", asks for contact, asks for her email, etc.) — politely ask for their NAME, then COMPANY, then EMAIL, one at a time. Do not pile all three into one message.
3. Once you have all three, thank them and say their details have been shared with Adeena. If they shared a message/opportunity, summarize it back in one line.
4. Keep replies short (1–4 sentences). Be confident, not salesy. Use markdown sparingly.
5. Never invent facts not in the FACTS section. If unsure, say so and offer to take their details.

FACTS:
- Adeena is an undergraduate at IIT Madras.
- Skills: Frontend Development, React, Tailwind CSS, AI Automation, Digital Marketing, Website Development, MVP Building, Video Editing, Content Creation, Social Media Marketing, IoT, Coding.
- Built 3+ MVP products: AI Portfolio Chatbot, Wedding RSVP & Management MVP, StudyFlow (Tamil Nadu Board LLM for 12th students), StudyTime (focus time-tracker), Content Studio (daily content tailoring), AI Automation Agency stack, Vellore.ai website.
- Freelance work: produced UGC and brand films for Ritz-Carlton and Ritz Paris freelance collaborations.
- Content: 21,000+ YouTube views, runs social campaigns end-to-end (script, shoot, edit).
- Case study: 15-day jewelry brand campaign — +15% engagement, stronger audience interaction.
- Certifications across Frontend Development, Technology, IoT, Coding, and Digital Marketing.

Tone: confident IIT student who ships. Concise. Curious about the visitor.`;

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const body = (await request.json()) as {
          messages?: UIMessage[];
          sessionId?: string;
        };
        const messages = body.messages;
        if (!Array.isArray(messages)) {
          return new Response("Messages are required", { status: 400 });
        }
        const apiKey = process.env.LOVABLE_API_KEY;
        if (!apiKey) {
          return new Response("Missing LOVABLE_API_KEY", { status: 500 });
        }

        const gateway = createLovableAiGatewayProvider(apiKey);
        const result = streamText({
          model: gateway("google/gemini-3-flash-preview"),
          system: SYSTEM_PROMPT,
          messages: await convertToModelMessages(messages),
        });

        const supabase = createClient<Database>(
          process.env.SUPABASE_URL!,
          process.env.SUPABASE_PUBLISHABLE_KEY!,
          { auth: { storage: undefined, persistSession: false, autoRefreshToken: false } },
        );

        return result.toUIMessageStreamResponse({
          originalMessages: messages,
          onFinish: async ({ messages: finalMessages }) => {
            try {
              const sessionId = body.sessionId;
              if (!sessionId) return;
              // Ensure session row exists
              await supabase
                .from("chat_sessions")
                .upsert({ id: sessionId }, { onConflict: "id" });
              const last = finalMessages.slice(-2); // user + assistant
              for (const m of last) {
                if (m.role !== "user" && m.role !== "assistant") continue;
                const text = m.parts
                  .map((p) => (p.type === "text" ? p.text : ""))
                  .join("")
                  .trim();
                if (!text) continue;
                await supabase.from("chat_messages").insert({
                  session_id: sessionId,
                  role: m.role,
                  content: text,
                });
              }
            } catch (e) {
              console.error("[chat] persist error", e);
            }
          },
        });
      },
    },
  },
});
