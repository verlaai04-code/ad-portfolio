import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { ExternalLink, Github } from "lucide-react";
import { VideoPlayer } from "@/components/VideoPlayer";
import { PROJECTS } from "@/lib/portfolio";

export const Route = createFileRoute("/projects")({
  head: () => ({
    meta: [
      { title: "Projects — Adeena's Portfolio" },
      {
        name: "description",
        content:
          "AI products, MVPs, brand campaigns and freelance work by Adeena, IIT Madras student.",
      },
      { property: "og:title", content: "Projects by Adeena" },
      {
        property: "og:description",
        content: "AI Portfolio Chatbot, StudyFlow LLM, Content Studio, Ritz campaigns and more.",
      },
    ],
  }),
  component: ProjectsPage,
});

function ProjectsPage() {
  return (
    <div className="relative pt-32 md:pt-40">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-[600px] bg-gradient-to-b from-gold/5 to-transparent" />
      <section className="mx-auto max-w-7xl px-6 pb-12">
        <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">
          Projects · {PROJECTS.length}
        </p>
        <h1 className="mt-4 font-display text-5xl leading-tight md:text-7xl">
          Things I've <span className="italic text-gradient">shipped</span>.
        </h1>
        <p className="mt-6 max-w-2xl text-lg text-muted-foreground">
          From AI products to brand films — a tour through the work.
        </p>
      </section>

      <section className="mx-auto max-w-7xl space-y-24 px-6 py-12 md:py-20">
        {PROJECTS.map((p, i) => (
          <motion.article
            key={p.slug}
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
            className={`grid gap-10 md:grid-cols-12 md:gap-12 ${
              i % 2 === 1 ? "md:[direction:rtl]" : ""
            }`}
          >
            <div className="relative md:col-span-7 md:[direction:ltr]">
              <div className="relative overflow-hidden rounded-3xl border border-stroke bg-surface">
                <div className="aspect-[16/10] w-full">
                  {p.video ? (
                    <VideoPlayer
                      src={p.video}
                      autoPlay
                      className="h-full w-full object-cover"
                    />
                  ) : (
                    <div className="grid h-full w-full place-items-center bg-gradient-to-br from-surface-2 via-surface to-background">
                      <span className="font-display text-8xl italic text-muted-foreground/40">
                        {String(i + 1).padStart(2, "0")}
                      </span>
                    </div>
                  )}
                </div>
              </div>
              <div className="pointer-events-none absolute -inset-4 -z-10 rounded-[2rem] bg-gradient-to-br from-azure/10 to-gold/10 blur-2xl" />
            </div>

            <div className="md:col-span-5 md:[direction:ltr]">
              <p className="text-[11px] uppercase tracking-[0.3em] text-gold">
                {p.category}
              </p>
              <h2 className="mt-3 font-display text-3xl leading-tight md:text-5xl">
                {p.title}
              </h2>
              <p className="mt-4 text-base text-muted-foreground md:text-lg">{p.blurb}</p>

              <div className="mt-6">
                <p className="text-[11px] uppercase tracking-[0.25em] text-muted-foreground">
                  Tech
                </p>
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {p.tech.map((t) => (
                    <span
                      key={t}
                      className="rounded-full border border-stroke bg-surface px-2.5 py-1 text-[11px] text-foreground/85"
                    >
                      {t}
                    </span>
                  ))}
                </div>
              </div>

              <ul className="mt-5 space-y-1.5 text-sm text-foreground/90">
                {p.features.map((f) => (
                  <li key={f} className="flex items-start gap-2">
                    <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-gradient-to-r from-azure to-gold" />
                    {f}
                  </li>
                ))}
              </ul>

              <div className="mt-7 flex flex-wrap gap-2">
                {p.liveUrl && (
                  <a
                    href={p.liveUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-2 rounded-full bg-foreground px-4 py-2 text-sm font-medium text-background hover:scale-[1.03] transition-transform"
                  >
                    Live demo <ExternalLink className="h-3.5 w-3.5" />
                  </a>
                )}
                {p.githubUrl && (
                  <a
                    href={p.githubUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-2 rounded-full border border-stroke px-4 py-2 text-sm hover:border-azure"
                  >
                    <Github className="h-3.5 w-3.5" /> Source
                  </a>
                )}
              </div>
            </div>
          </motion.article>
        ))}
      </section>
    </div>
  );
}
