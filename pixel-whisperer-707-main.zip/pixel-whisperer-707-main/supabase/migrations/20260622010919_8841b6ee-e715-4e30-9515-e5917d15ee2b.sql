
DROP POLICY IF EXISTS "anyone can read sessions" ON public.chat_sessions;
DROP POLICY IF EXISTS "anyone can create sessions" ON public.chat_sessions;
CREATE POLICY "sessions insert with valid id"
  ON public.chat_sessions FOR INSERT TO anon, authenticated
  WITH CHECK (id IS NOT NULL);
CREATE POLICY "deny select chat_sessions"
  ON public.chat_sessions AS RESTRICTIVE FOR SELECT TO anon, authenticated
  USING (false);

DROP POLICY IF EXISTS "anyone can read messages" ON public.chat_messages;
DROP POLICY IF EXISTS "anyone can insert messages" ON public.chat_messages;
CREATE POLICY "messages insert with content"
  ON public.chat_messages FOR INSERT TO anon, authenticated
  WITH CHECK (
    session_id IS NOT NULL
    AND role IN ('user','assistant','system')
    AND length(content) > 0
    AND length(content) <= 10000
  );
CREATE POLICY "deny select chat_messages"
  ON public.chat_messages AS RESTRICTIVE FOR SELECT TO anon, authenticated
  USING (false);

DROP POLICY IF EXISTS "anyone can submit lead" ON public.leads;
CREATE POLICY "lead insert with valid fields"
  ON public.leads FOR INSERT TO anon, authenticated
  WITH CHECK (
    length(name) BETWEEN 1 AND 100
    AND length(email) BETWEEN 3 AND 255
    AND email LIKE '%_@_%.__%'
    AND (company IS NULL OR length(company) <= 150)
    AND (message IS NULL OR length(message) <= 2000)
  );
CREATE POLICY "deny read leads"
  ON public.leads AS RESTRICTIVE FOR SELECT TO anon, authenticated
  USING (false);
CREATE POLICY "deny update leads"
  ON public.leads AS RESTRICTIVE FOR UPDATE TO anon, authenticated
  USING (false) WITH CHECK (false);
CREATE POLICY "deny delete leads"
  ON public.leads AS RESTRICTIVE FOR DELETE TO anon, authenticated
  USING (false);
